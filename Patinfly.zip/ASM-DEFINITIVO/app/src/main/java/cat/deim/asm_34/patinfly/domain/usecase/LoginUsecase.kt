package cat.deim.asm_34.patinfly.domain.usecase

import android.util.Log
import cat.deim.asm_34.patinfly.domain.repository.IUserRepository
import cat.deim.asm_34.patinfly.domain.models.User

class LoginUsecase(private val userRepository: IUserRepository) {

    fun execute(credentials: Credentials): Boolean {
        return try {
            val user = userRepository.getUserByEmail(credentials.email)
            return if (user != null && user.hashedPassword == credentials.password) {
                userRepository.setUser(user) // Guardamos como "usuario actual"
                true
            } else {
                false
            }

        } catch (e: Exception) {
            Log.e("LoginUsecase", "Error in login process", e)
            false
        }
    }
}
