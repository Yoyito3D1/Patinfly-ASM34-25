package cat.deim.asm_34.patinfly.data.datasource.model

data class PricingDataModel(
    val plans: List<DataPlanModel>
)
