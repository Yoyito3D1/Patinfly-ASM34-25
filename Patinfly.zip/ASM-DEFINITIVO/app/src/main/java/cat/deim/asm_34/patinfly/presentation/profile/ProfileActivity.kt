package cat.deim.asm_34.patinfly.presentation.profile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import cat.deim.asm_34.patinfly.data.datasource.local.UserDataSource
import cat.deim.asm_34.patinfly.data.repository.UserRepository
import cat.deim.asm_34.patinfly.domain.usecase.GetUserUseCase
import cat.deim.asm_34.patinfly.ui.theme.PatinflyTheme

class ProfileActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val user = GetUserUseCase.execute(this)

        setContent {
            PatinflyTheme {
                if (user != null) {
                    ProfileForm(user)
                }
            }
        }
    }
}
