package cat.deim.asm_34.patinfly.presentation.main

import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import cat.deim.asm_34.patinfly.R
import cat.deim.asm_34.patinfly.domain.models.Bike
import cat.deim.asm_34.patinfly.domain.models.User
import cat.deim.asm_34.patinfly.presentation.bikelist.BikeListActivity
import cat.deim.asm_34.patinfly.presentation.bikelist.BikeViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

import cat.deim.asm_34.patinfly.presentation.profile.ProfileActivity

@Composable
fun MainForm(
    user: User,
    bikeViewModel: BikeViewModel = viewModel()
) {
    val context = LocalContext.current

    LaunchedEffect(Unit) { bikeViewModel.fetchBikes(context) }
    val bikes = bikeViewModel.bikes.observeAsState(emptyList())

    val surfaceColor   = MaterialTheme.colorScheme.surface
    val onSurfaceColor = MaterialTheme.colorScheme.onSurface

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(32.dp)
        ) {

            Text(
                "Patinfly",
                style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Black),
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )

            Card(
                colors  = CardDefaults.cardColors(containerColor = surfaceColor),
                shape   = MaterialTheme.shapes.extraLarge,
                elevation = CardDefaults.cardElevation(4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        context.startActivity(Intent(context, ProfileActivity::class.java))
                    }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(R.drawable.profile_image),
                        contentDescription = null,
                        modifier = Modifier
                            .size(72.dp)
                            .clip(MaterialTheme.shapes.extraLarge)
                    )
                    Spacer(Modifier.width(20.dp))
                    Text(
                        buildAnnotatedString {
                            withStyle(
                                MaterialTheme.typography.titleMedium
                                    .toSpanStyle()
                                    .copy(fontWeight = FontWeight.Bold)
                            ) { append(user.name) }
                            append(" account")
                        },
                        color = onSurfaceColor,
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Around you",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
                Text("→", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
            }

            if (bikes.value.isEmpty()) {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.CenterHorizontally))
            } else {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(170.dp)
                ) {
                    items(bikes.value) { bike ->
                        BikeAroundItem(bike) {
                            context.startActivity(Intent(context, BikeListActivity::class.java))
                        }
                    }
                }
            }

            Text(
                "Categories",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(32.dp)
            ) {
                CategoryItem(R.drawable.bike_type_1, "Urban") {
                    context.startActivity(Intent(context, BikeListActivity::class.java))
                }
                CategoryItem(R.drawable.bike_type_2, "Electric") {
                    context.startActivity(Intent(context, BikeListActivity::class.java))
                }
            }
        }

        FloatingActionButton(
            onClick  = { /* TODO acción QR */ },
            containerColor = Color(0xFF00E676),
            shape = MaterialTheme.shapes.large,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .size(72.dp)
        ) {
            Text("QR", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}


@Composable
private fun BikeAroundItem(
    bike: Bike,
    onClick: () -> Unit
) {
    val surfaceColor = MaterialTheme.colorScheme.surface
    Card(
        shape   = MaterialTheme.shapes.medium,
        elevation = CardDefaults.cardElevation(4.dp),
        colors  = CardDefaults.cardColors(containerColor = surfaceColor),
        modifier = Modifier
            .width(140.dp)
            .clickable { onClick() }
    ) {
        Column {
            Image(
                painter = painterResource(R.drawable.bike_sample),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
                    .clip(MaterialTheme.shapes.medium)
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "${(bike.meters / 1000.0).format(1)} km away",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(start = 8.dp, bottom = 8.dp)
            )
        }
    }
}

@Composable
private fun CategoryItem(
    icon: Int,
    label: String,
    onClick: () -> Unit
) {
    val surfaceColor = MaterialTheme.colorScheme.surface
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Card(
            shape   = MaterialTheme.shapes.extraLarge,
            elevation = CardDefaults.cardElevation(2.dp),
            colors  = CardDefaults.cardColors(containerColor = surfaceColor),
            modifier = Modifier
                .size(80.dp)
                .clickable { onClick() }
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                Image(
                    painter = painterResource(icon),
                    contentDescription = null,
                    modifier = Modifier.size(36.dp)
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}

private fun Double.format(digits: Int) = "%.${digits}f".format(this)
