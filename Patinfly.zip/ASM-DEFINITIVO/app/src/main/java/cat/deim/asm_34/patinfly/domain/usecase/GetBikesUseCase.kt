package cat.deim.asm_34.patinfly.domain.usecase

import android.content.Context
import cat.deim.asm_34.patinfly.data.datasource.local.BikeDataSource
import cat.deim.asm_34.patinfly.data.repository.BikeRepository
import cat.deim.asm_34.patinfly.domain.models.Bike

class GetBikesUseCase {
    companion object {
        fun execute(context: Context): List<Bike> {
            return BikeRepository(BikeDataSource.getInstance(context)).getAll().toList()
        }
    }
}
