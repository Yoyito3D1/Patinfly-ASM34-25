package cat.deim.asm_34.patinfly.data.repository

import cat.deim.asm_34.patinfly.data.datasource.ISystemPricingPlanDataSource
import cat.deim.asm_34.patinfly.data.datasource.model.SystemPricingPlanModel
import cat.deim.asm_34.patinfly.domain.models.SystemPricingPlan
import cat.deim.asm_34.patinfly.domain.repository.ISystemPricingPlanRepository

class SystemPricingPlanRepository(
    private val dataSource: ISystemPricingPlanDataSource
) : ISystemPricingPlanRepository {

    override fun insert(systemPricingPlan: SystemPricingPlan): Boolean {
        return dataSource.insert(SystemPricingPlanModel.fromDomain(systemPricingPlan))
    }

    override fun getAll(): Collection<SystemPricingPlan> {
        return dataSource.getAll().map { it.toDomain() }
    }

    override fun getById(planId: String): SystemPricingPlan? {
        return dataSource.getById(planId)?.toDomain()
    }

    override fun update(systemPricingPlan: SystemPricingPlan): Boolean {
        return dataSource.update(SystemPricingPlanModel.fromDomain(systemPricingPlan))
    }

    override fun delete(planId: String): Boolean {
        return dataSource.delete(planId)
    }
}
