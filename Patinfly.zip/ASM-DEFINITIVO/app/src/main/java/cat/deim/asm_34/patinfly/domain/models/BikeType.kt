package cat.deim.asm_34.patinfly.domain.models

import java.util.UUID

data class BikeType(
    val uuid: String,
    val name: String,
    val type: String
)