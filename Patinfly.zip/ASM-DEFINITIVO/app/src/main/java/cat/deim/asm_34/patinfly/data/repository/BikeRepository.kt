package cat.deim.asm_34.patinfly.data.repository

import cat.deim.asm_34.patinfly.data.datasource.IBikeDataSource
import cat.deim.asm_34.patinfly.data.datasource.model.BikeModel
import cat.deim.asm_34.patinfly.domain.models.Bike
import cat.deim.asm_34.patinfly.domain.repository.IBikeRepository

class BikeRepository(private val dataSource: IBikeDataSource) : IBikeRepository {

    override fun insert(bike: Bike): Boolean {
        return dataSource.insert(BikeModel.fromDomain(bike))
    }

    override fun getAll(): Collection<Bike> {
        return dataSource.getAll().map { it.toDomain() }
    }

    override fun getById(uuid: String): Bike? {
        return dataSource.getById(uuid)?.toDomain()
    }

    override fun update(bike: Bike): Boolean {
        return dataSource.update(BikeModel.fromDomain(bike))
    }

    override fun delete(uuid: String): Boolean {
        return dataSource.delete(uuid)
    }
}
