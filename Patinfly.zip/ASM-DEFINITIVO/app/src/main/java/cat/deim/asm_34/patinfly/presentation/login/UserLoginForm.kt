import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cat.deim.asm_34.patinfly.R
import cat.deim.asm_34.patinfly.data.datasource.local.UserDataSource
import cat.deim.asm_34.patinfly.data.repository.UserRepository
import cat.deim.asm_34.patinfly.domain.usecase.Credentials
import cat.deim.asm_34.patinfly.domain.usecase.LoginUsecase
import cat.deim.asm_34.patinfly.presentation.main.MainActivity

@Composable
fun UserLoginForm(loginUsecase: LoginUsecase?) {
    val context = LocalContext.current
    var credentials by remember { mutableStateOf(Credentials()) }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp),
        color = Color.White
    ) {
        Column(
            verticalArrangement = Arrangement.SpaceEvenly,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.drawable.login_image),
                contentDescription = stringResource(R.string.login_image_description),
                modifier = Modifier
                    .height(220.dp)
                    .fillMaxWidth()
            )

            Text(
                text = stringResource(R.string.login_title),
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )

            Column {
                TextField(
                    value = credentials.email,
                    onValueChange = { credentials = credentials.copy(email = it) },
                    label = { Text(stringResource(R.string.email_label)) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                )
                TextField(
                    value = credentials.password,
                    onValueChange = { credentials = credentials.copy(password = it) },
                    label = { Text(stringResource(R.string.password_label)) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                )
            }

            Text(
                text = stringResource(R.string.forgot_password),
                fontSize = 14.sp,
                color = Color.Gray,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 8.dp),
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                horizontalArrangement = Arrangement.End
            ) {
                FloatingActionButton(
                    onClick = {
                        if (loginUsecase!!.execute(credentials)) {
                            val intent = Intent(context, MainActivity::class.java)
                            context.startActivity(intent)
                        }
                    },
                    containerColor = Color(0xFF00E676),
                    shape = MaterialTheme.shapes.large,
                    modifier = Modifier.size(72.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = stringResource(R.string.login_button_description),
                        tint = Color.White
                    )
                }
            }

        }
    }
}
