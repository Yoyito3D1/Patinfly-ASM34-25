package cat.deim.asm_34.patinfly.data.datasource.model

data class BikeListWrapperModel(
    val version: String,
    val bike: List<BikeModel>
)