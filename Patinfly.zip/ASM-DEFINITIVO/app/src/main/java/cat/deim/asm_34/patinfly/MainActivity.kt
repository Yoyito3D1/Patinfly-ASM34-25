package cat.deim.asm_34.patinfly

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import cat.deim.asm_34.patinfly.data.datasource.local.*
import cat.deim.asm_34.patinfly.data.repository.*
import cat.deim.asm_34.patinfly.domain.models.*
import cat.deim.asm_34.patinfly.domain.repository.*
import cat.deim.asm_34.patinfly.ui.theme.PatinflyTheme
import java.util.*

class MainActivity : ComponentActivity() {

    private val TAG = "MainActivity"

    // Repos
    private lateinit var userRepo: IUserRepository
    private lateinit var bikeRepo: IBikeRepository
    private lateinit var pricingRepo: ISystemPricingPlanRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate")

        // Inicializa repos
        userRepo = UserRepository(UserDataSource.getInstance(applicationContext))
        bikeRepo = BikeRepository(BikeDataSource.getInstance(applicationContext))
        pricingRepo = SystemPricingPlanRepository(SystemPricingPlanDataSource.getInstance(applicationContext))

        enableEdgeToEdge()
        setContent {
            PatinflyTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Greeting(
                        name = "Android",
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "onStart")

        inicialitzarRepositoris()

        val loadedUser = userRepo.getUser()
        val loadedBikes = bikeRepo.getAll()
        val loadedPlans = pricingRepo.getAll()

        Log.d(TAG, "USUARIO desde JSON: $loadedUser")
        Log.d(TAG, "BICICLETAS desde JSON: ${loadedBikes.size}")
        Log.d(TAG, "PLANES desde JSON: ${loadedPlans.size}")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "onStop")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy")
    }

    private fun inicialitzarRepositoris() {
        val uuid = UUID.randomUUID()

        val user = User(
            uuid = uuid,
            name = "Demo User",
            email = "demo@demo.cat",
            hashedPassword = "demo123",
            creationDate = Date().toString(),
            lastConnection = Date().toString(),
            deviceId = "dev123"
        )

        val bike = Bike(
            uuid = "ZSZSSASASASAS",
            name = "TestBike",
            bikeType = BikeType("asjajs", "Road", "RBX001"),
            creationDate = Date(),
            lastMaintenanceDate = Date(),
            inMaintenance = false,
            isActive = true,
            batteryLevel = 90,
            meters = 500
        )

        val pricing = SystemPricingPlan(
            lastUpdated = Date(),
            ttl = 0,
            version = "1.0",
            dataPlans = listOf(
                DataPlan(
                    planId = "planX",
                    name = LocalizedText("Test Plan", "en"),
                    currency = "EUR",
                    price = 1.0,
                    isTaxable = true,
                    description = LocalizedText("Demo plan", "en"),
                    perKmPricing = Pricing(0, 0.0, 1),
                    perMinPricing = Pricing(0, 0.25, 1)
                )
            )
        )

        userRepo.setUser(user)
        bikeRepo.insert(bike)
        pricingRepo.insert(pricing)

        Log.d(TAG, "User insertado: ${userRepo.getUser()}")
        Log.d(TAG, "Bike insertada: ${bikeRepo.getById(bike.uuid.toString())}")
        Log.d(TAG, "Plan insertado: ${pricingRepo.getById("planX")}")
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    PatinflyTheme {
        Greeting("Android")
    }
}
