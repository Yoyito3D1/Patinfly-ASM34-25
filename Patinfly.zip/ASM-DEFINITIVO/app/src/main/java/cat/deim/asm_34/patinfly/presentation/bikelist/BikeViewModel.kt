package cat.deim.asm_34.patinfly.presentation.bikelist

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import cat.deim.asm_34.patinfly.domain.models.Bike
import cat.deim.asm_34.patinfly.domain.usecase.GetBikesUseCase
import kotlinx.coroutines.launch

class BikeViewModel : ViewModel() {
    private val _bikes = MutableLiveData<List<Bike>>()
    val bikes: LiveData<List<Bike>> = _bikes

    fun fetchBikes(context: Context) {
        viewModelScope.launch {
            try {
                val bikesList = GetBikesUseCase.execute(context)
                _bikes.value = bikesList
            } catch (e: Exception) {
                println("Error en BikeViewModel: ${e.message}")
            }
        }
    }
}
