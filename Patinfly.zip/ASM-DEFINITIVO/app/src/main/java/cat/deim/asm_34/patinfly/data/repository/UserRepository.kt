package cat.deim.asm_34.patinfly.data.repository

import cat.deim.asm_34.patinfly.data.datasource.IUserDataSource
import cat.deim.asm_34.patinfly.data.datasource.model.UserModel
import cat.deim.asm_34.patinfly.domain.models.User
import cat.deim.asm_34.patinfly.domain.repository.IUserRepository
import java.util.UUID

class UserRepository(private val dataSource: IUserDataSource) : IUserRepository {

    override fun setUser(user: User): Boolean {
        return dataSource.setUser(UserModel.fromDomain(user))
    }

    override fun getUser(): User? {
        return dataSource.getUser()?.toDomain()
    }

    override fun updateUser(user: User): User? {
        return dataSource.updateUser(UserModel.fromDomain(user))?.toDomain()
    }

    override fun deleteUser(): User? {
        return dataSource.deleteUser()?.toDomain()
    }

    override fun getUserByUUID(uuid: UUID): User? {
        return dataSource.getUserByUUID(uuid)?.toDomain()
    }

    override fun getUserByEmail(email: String): User? {
        return dataSource.getUserByEmail(email)?.toDomain()
    }
}

