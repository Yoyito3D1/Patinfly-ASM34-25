package cat.deim.asm_34.patinfly.domain.repository

import cat.deim.asm_34.patinfly.domain.models.User
import java.util.UUID

interface IUserRepository {
    fun setUser(user: User): Boolean
    fun getUser(): User?
    fun updateUser(user: User): User?
    fun deleteUser(): User?

    fun getUserByUUID(uuid: UUID): User?
    fun getUserByEmail(email: String): User?
}