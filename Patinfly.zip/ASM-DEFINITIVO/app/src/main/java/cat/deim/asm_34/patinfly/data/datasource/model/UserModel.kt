package cat.deim.asm_34.patinfly.data.datasource.model

import cat.deim.asm_34.patinfly.domain.models.User
import java.util.UUID

data class UserModel(
    val uuid: String,
    val name: String,
    val email: String,
    val hashed_password: String,
    val creation_date: String,
    val last_connection: String,   //hemos usado los nombres del json pero tambien se puede usar etiquetra @serializedName("last_connection") es lo mismo
    val device_id: String
) {
    fun toDomain(): User {
        return User(
            uuid = UUID.fromString(uuid),
            name = name,
            email = email,
            hashedPassword = hashed_password,
            creationDate = creation_date,
            lastConnection = last_connection,
            deviceId = device_id
        )
    }

    companion object {
        fun fromDomain(user: User): UserModel {
            return UserModel(
                uuid = user.uuid.toString(),
                name = user.name,
                email = user.email,
                hashed_password = user.hashedPassword,
                creation_date = user.creationDate,
                last_connection = user.lastConnection,
                device_id = user.deviceId
            )
        }
    }
}
