package cat.deim.asm_34.patinfly.domain.usecase

import android.content.Context
import cat.deim.asm_34.patinfly.data.datasource.local.UserDataSource
import cat.deim.asm_34.patinfly.data.repository.UserRepository
import cat.deim.asm_34.patinfly.domain.models.User

class GetUserUseCase  {
    companion object {
        fun execute(context: Context): User? {
            return UserRepository(UserDataSource.getInstance(context)).getUser()
        }
    }
}
